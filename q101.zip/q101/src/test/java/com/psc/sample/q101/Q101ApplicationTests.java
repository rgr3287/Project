package com.psc.sample.q101;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Q101ApplicationTests {

	@Test
	void contextLoads() {
	}

}
