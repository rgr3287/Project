package com.psc.sample.q101.dto;

public enum Role {
	ROLE_USER;
}
